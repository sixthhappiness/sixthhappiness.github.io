This Qt project reproduces much of the behavior of a Cocoa document-based application: Open, Save, Save As sheet file dialogs; Quit and Close confirmation dialogs when modified documents are present; logout, restart, and shutdown handling; choosing quit in the dock menu; dropping files onto the application icon in the Finder or dock; recent files menu; and window menu.

It can be built with either the Carbon build or Cocoa builds of Qt.

It can also be built and provides reasonable interaction under Linux and Windows.

It has been tested with Qt 4.5.2 and Qt Creator 1.2.0, in Mac OS X 10.5.7, Ubuntu Linux 9.0.4, and Windows XP SP3.

It requires the Qt Solutions component QtSingleApplication available here:

  http://www.qtsoftware.com/products/appdev/add-on-products/catalog/4/Utilities/qtsingleapplication

After its installion, edit the paths in QtDocBasedApp.pro to point to QtSingleApplication's location.

The project should build on Linux and Windows as is.  On Mac OS X, the project can use the 32-bit or 64-bit Cocoa build, or the 32-bit Carbon build of Qt (Intel or PPC, or any combination of these) by editing QtDocBaseApp.pro.  Of course suitable builds of the Qt frameworks must have been properly installed for a given choice to build correctly.  The Qt frameworks installed by qt-sdk-mac-opensource-2009.03.dmg is the 32-bit Carbon build.  To use Cocoa (both 32-bit and 64-bit), first install this SDK, then install qt-mac-cocoa-opensource-4.5.2.dmg:

  http://get.qtsoftware.com/qt/source/qt-mac-cocoa-opensource-4.5.2.dmg

Also one can build and install Qt oneself to get any combination of builds.

Note also that to test or observe QtDocBasedApp's behavior at logout, restart, or shutdown, one must start QtDocBasedApp.app from the Finder and not from within Qt Creator.  When Qt Creator quits it kills its child processes which causes an invocation of QtDocBasedApp.app from it to simply quit.
