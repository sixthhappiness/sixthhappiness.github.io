CHARTTRANSLATE

ChartTranslate is an utility program for conversion of chord charts
among various file formats.  It reads files in the following formats:

  MyJazzBand (.mjb or .toe),
  Band in a Box (.sg? or .mg?), and
  XML exported by Finale (.xml)

and writes files in the following formats:

  MyJazzBand (.mjb or .toe),
  Band in a Box (.sg?),
  XML for imported into Finale (.xml), and 
  Lilypond (.ly).

ChartTranslate was written in conjunction with my jazz accompaniment
generation program MyJazzBand 2 Lite (MJB2Lite).  Information about
and downloads for ChartTranslate and MJB2Lite can be found at my
website:

  http://www.sixthhappiness.ca/index.html

Questions about ChartTranslate can be asked on my bulletin board also
at this website,

You are free to use ChartTranslate under conditions laid out in the
file LICENSE.txt.  But it is not free/GPL license software.  Please do
not redistribute it.  Its software license prohibits you from doing
so.  If you would like to tell your friend about it, I will greatly
appreciate it if you provide a link to my website instead.

USAGE

ChartTranslate is useful for two main reasons.  It can be used
together with MJB2Lite to allow editing of files in Band-in-a-Box
(BiaB) format without using the BiaB application.  It can also be used
to print chord charts in BiaB or MyJazzBand file format in Finale or
Lilypond.

Numerous BiaB files can be found on and downloaded from the Web.
Although MJB2Lite can read files in both BiaB and MyJazzBand formats,
one will still need to use the BiaB application to edit BiaB files.
Using ChartTranslate, BiaB files can be converted into MyJazzBand
format and edited using a text editor.  The edited files can then be
used as input by MJB2Lite.

MJB2, the planned commercial version MJB2Llite, will have functions
for printing and formatting chord charts.  But before it is released,
it would be nice to be able to print charts from MyJazzBand or BiaB
files.  ChartTranslate allows one to convert such files to XML and
Lilypond formats.  The converted XML files can be read by Finale.
Lilypond is free.  So with ChartTranslate it provides a completely
cost-free solution for printed chord charts from files in BiaB format.

To use ChartTranslate on Mac OS X, the downloaded and unzipped folder
ChartTranslate should contain the application ChartTranslate.  Just
drag and drop one or more files of the recognized formats onto this
application icon.  A panel will allow the output format to be
selected.  The ChartTranslate window will stay open, so to quit,
choose "quit" from the ChartTranslate menu.

On Windows (tested only on Windows XP), the downloaded and unzipped
folder "dist" should contain the program "charttranslate.exe".  Drag
and drop one or more input files onto this program icon.  By default
output files are written in the MyJazzBand format.  To select another
output format, append '-toe', '-biab', '-xml', or '-ly' to the name of
the executable.  For example, changing the name of the executable to
"charttranslate-xml.exe" will make it write XML files.

Instead of changing the name of the executable, you can invoke
charttranslate from the command line:

  charttranslate (-t <type>) <inputfile> ...

where <type> is "toe", "biab", "xml", or "ly".

On other systems (such as Linux and BSD), make sure you have Python
2.5 installed.  The downloaded, gunzipped, and untarred directory
"dist" should contain the file charttranslate.py.  In a shell, type:

  python charttranslate.py (-t <type>) <inputfile> ...

Alternatively make charttranslate.py executable using "chmod".  Then
type:

  ./charttranslate.py (-t <type>) <inputfile> ...

If you have questions, please ask them on the bulletin board.

Enjoy!

Andrew Choi.
akochoi (at) shaw (dot) ca
