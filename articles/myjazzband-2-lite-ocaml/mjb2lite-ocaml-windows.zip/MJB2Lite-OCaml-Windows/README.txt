MYJAZZBAND 2 LITE - OCAML

MyJazzBand 2 Lite (MJB2Lite) is a complete rewrite of my shareware
program MyJazzBand in Python.  MJB2Lite-OCaml is a rewrite
(translation) of MJB2Lite in OCaml.  Since this new OCaml version is
superior in performance, design, and implementation, future
development of "the MJB2 series" will continue from it.

MyJazzBand, now discontinued, was a MIDI application for generating
jazz accompaniments.  MJB2Lite and MJB2Lite-OCaml have been written as
prototypes for testing composition algorithms that will be used in
MyJazzBand 2, a shareware program that I hope to build and release in
the future.

Information about and downloads for MJB2Lite-OCaml can be found at my
website:

  http://www.sixthhappiness.ca/index.html

Please ask questions about and discuss the MJB2Lite-OCaml program on
the bulletin board at that website,

MJB2Lite-OCaml is an on-going project and will be updated from time to
time.  I am also hoping that the release of MJB2Lite-OCaml will serve
as "advertisement" for my website and my future shareware.  For these
and other reasons, please do not redistribute MJB2Lite-OCaml.  The
software license I have chosen for it prohibits you from doing so.  I
will greatly appreciate it if you provide a link to my website
instead.

FILE FORMAT

MJB2Lite-OCaml reads chord charts in the MJB "native" format: text
files with extensions ".mjb" or ".toe".  Here is an example of the
contents of such a file:

Name: Blues #40
Meter: 4/4
Style: Swing
Key: F
Tempo: 132
Chorus: bars 1 to 12 (repeat 3 times)
Sections: 1A
| FMaj7 | Em7b5 A7 | Dm7 G7 | Cm7 F7 |
| BbMaj7 | Bbm7 | Am7 | Abm7 Db7 |
| Gm7 | C7 | FMaj7 D7 | Gm7 C7 |
| FMaj7 |

You can input your own chord charts using a text editor and save the
file in "plain text" format with an extension of ".mjb" or ".toe".

MJB2Lite-OCaml can also read chord charts in files written by the
Band-in-a-Box program.  Numerous files in this format can be found on
the Web.  Look for them with Google, for example:

  http://www.google.com/search?hl=en&rls=en&q=band-in-a-box+files+jazz&btnG=Search

BIAB format files have extensions ".sg?" or ".mg?", where ? is a digit
or letter.

Currently MJB2Lite-OCaml can only generate accompaniment for a chart
in 4/4 time in a "swing" style.  The style works well only in medium
tempo.

USAGE

On Mac OS X, the downloaded and unzipped folder MJB2Bite-OCaml should
contain the application MJB2Lite-OCaml.  This is an universal
application and will work on both PowerPC and Intel Macs.  Drag and
drop one or more input files in the MJB "native" or BIAB format (e.g.,
the included sample input file "Blues #40.mjb") onto this application
icon.  The generated MIDI accompaniment file will have the same name
as input file, but with the ".mid" extension added to the end.  The
MJBLite-OCaml window will stay open so you can read the error messages
if there are any.  To quit MJB2Lite-OCaml, choose "quit" from its
menu.  The generated MIDI files can be played in the Finder or
QuickTime Player, or imported into any MIDI sequencer.

On Windows (tested only on Windows XP), the downloaded and unzipped
folder "dist" should contain the program "mjb2lite-ocaml.exe".  Drag
and drop one or more input files onto this program icon.
Alternatively, you can invoke this program from the command line:

  mjb2lite-ocaml <inputfile> ...

The generated MIDI file can be played in Windows Media Player
(double-click on the MIDI file), or whichever program you have set up
to handle MIDI files in Windows.

On other systems (such as Linux and BSD), you need to have OCaml
3.10.0 installed (http://caml.inria.fr/).  The downloaded, gunzipped,
and untarred directory "dist" should contain the file mjb2lite.byte.
In a shell, type:

  ocamlrun mjb2lite.byte <inputfile> ...

Alternatively if your OCaml bytecode interpreter has been installed as
/usr/local/bin/ocamlrun, you can make mjb2lite.byte executable using
"chmod".  Then type:

  ./mjb2lite.byte <inputfile> ...

If you have questions, please ask them on the bulletin board.

Enjoy the MJB2Lite-OCaml program!

Andrew Choi.
akochoi (at) shaw (dot) ca
