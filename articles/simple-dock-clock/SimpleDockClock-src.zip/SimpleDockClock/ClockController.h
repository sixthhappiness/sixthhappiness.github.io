//
//  ClockController.h
//  SimpleDockClock
//
//  Created by Andrew Choi on 25/06/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//
//  Permission for the use of this code is granted only for research,
//  educational, and non-commercial purposes.
//
//  Redistribution of this code or its parts in any form without
//  permission, with or without modification, is prohibited.

#import <Cocoa/Cocoa.h>


@interface ClockController : NSObject {
	NSImage *clockFaceImage;
	NSImage *hourHandImage;
	NSImage *minuteHandImage;
	
	NSTimer *timer;
}

@end
