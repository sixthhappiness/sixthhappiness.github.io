//
//  FCIMInputController.h
//  FCIM
//
//  Created by Andrew Choi on 22/08/08.
//  Copyright 2008 Andrew Choi. All rights reserved.
//

/*
 
 Permission for the use of this code is granted only for research, educational, and non-commercial purposes.

 Redistribution of this code or its parts in source, binary, and any other form without permission, with or without modification, is prohibited.  Modifications include, but are not limited to, translation to other programming languages and reuse of tables, constant definitions, and API's defined in it.

 Andrew Choi is not liable for any losses or damages caused by the use of this software.
 
 */


#import <Cocoa/Cocoa.h>
#import <InputMethodKit/InputMethodKit.h>

@interface FCIMInputController : IMKInputController {
	id client;
	NSMutableString *compositionBuffer;
	NSArray *currentCandidates;
}

@end
