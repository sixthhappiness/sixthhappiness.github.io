//
//  AppDelegate.h
//  SwitchMainDisplay
//
//  Created by Andrew Choi on 12-04-26.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end
