/*
  Permission for the use of this code is granted only for research, educational, and non-commercial purposes.

  Redistribution of this code or its parts in source, binary, and any other form without permission, with or without modification, is prohibited.  Modifications include, but are not limited to, translation to other programming languages and reuse of tables, constant definitions, and API's defined in it.

  Andrew Choi is not liable for any losses or damages caused by the use of this code.

  Copyright 2009 Andrew Choi.
*/

#ifndef CHORDNAMEMODEL_H
#define CHORDNAMEMODEL_H

#include <QAbstractListModel>
#include <QModelIndex>
#include <QVariant>

class ChordNameModel : public QAbstractListModel
{
public:
    ChordNameModel(QObject *parent = 0);

    int rowCount(const QModelIndex &parent) const;
    QVariant data(const QModelIndex &index, int role) const;
};

#endif // CHORDNAMEMODEL_H
