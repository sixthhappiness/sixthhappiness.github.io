/*
  Permission for the use of this code is granted only for research, educational, and non-commercial purposes.

  Redistribution of this code or its parts in source, binary, and any other form without permission, with or without modification, is prohibited.  Modifications include, but are not limited to, translation to other programming languages and reuse of tables, constant definitions, and API's defined in it.

  Andrew Choi is not liable for any losses or damages caused by the use of this code.

  Copyright 2009 Andrew Choi.
*/

#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QStringList>
#include <QChar>

class Constants
{
public:
    static Constants *instance();

    const QStringList chordTypeNames() { return _chordTypeNames; }
    const QStringList noteNames() { return _noteNames; }

private:
    Constants();
    static Constants *_instance;

    QStringList _chordTypeNames;
    QStringList _noteNames;
};

#endif // CONSTANTS_H
