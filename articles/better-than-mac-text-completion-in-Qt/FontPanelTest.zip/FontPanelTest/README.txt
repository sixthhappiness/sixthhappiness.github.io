This Qt project demonstrates the implementation of text completion for a QLineEdit widget that provides a very Mac-like interaction.

It works well on Mac, Linux, and Windows.

It has been tested with Qt 4.5.2 and Qt Creator 1.2.0, in Mac OS X 10.5.7, Ubuntu Linux 9.0.4, and Windows XP SP3.

It also demonstrates the use of a font panel that behaves like a native Mac font panel.

It also contains sample code that shows the use of a validator, how to provide a concrete implementation of an abstract list model, and how widgets can be dynamically resized.