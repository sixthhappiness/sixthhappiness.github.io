(* Make sure the following points to the top directory of the project
if it is ever moved.  *)

#cd "/Users/choi/Projects/T2";;


#load "str.cma";;
#load "nums.cma";;
let pp_num formatter x = Format.pp_print_string formatter (Num.string_of_num x);
#install_printer pp_num;;
#load "unix.cma";;

#directory "_build/toe";;
#load "toe.cma";;

#install_printer Intvl.pp;;
#install_printer Note.pp;;
#install_printer Chordtype.pp;;
#install_printer Chord.pp;;
#install_printer Scaletype.pp;;
#install_printer Scale.pp;;
#install_printer Midinote.pp;;

#install_printer Noteset.noteset_pp;;

#directory "_build/romanana";;
#load "romanana.cma";;
#install_printer Roman.pp;;
#install_printer Simplchord.pp;;
#install_printer Romanchord.pp;;

