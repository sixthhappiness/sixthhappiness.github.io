The main purpose for the release of the code in this directory is to
demonstrate the algorithm described in my paper: Harmonic Analysis of
Jazz Chord Sequences (submitted for publication).

Download and description of this program (called "T2"), those for T2G,
a GUI version of T2, and contact information can be found here:

    http://www.sixthhappiness.ca/jazz-harmonic-analysis/index.html

Here are the terms of the use of this code (this is emphatically NOT
free software):

-----
Permission for the use of this code is granted only for research,
educational, and non-commercial purposes.

Redistribution of this code or its parts in source, binary, and any
other form without permission, with or without modification, is
prohibited.  Modifications include, but are not limited to,
translation to other programming languages and reuse of tables,
constant definitions, and APIs defined in it.

Andrew Choi is not liable for any losses or damages caused by the use
of this software.

Copyright 2008, 2009 Andrew Choi.
-----

This code has been developed and tested using OCaml version 3.11.0:

  http://caml.inria.fr/

To build T2, from the top directory, type:

  ocamlbuild romanana/t2.native

(replace t2.native with t2.byte to build a bytecode version).

Then use T2 to analyze a chord chart by entering:

  ./t2.native <chord-chart-filename>

Examples of the format of chord chart files can be found in the
directory Testfiles.

To run T2 through all the files in Testfiles, type:

  for f in Testfiles/*; do
    echo "### $f ###"
    ./t2.native $f
  done

Have fun!

Andrew Choi.
Calgary, Alberta, Canada.  2009.
