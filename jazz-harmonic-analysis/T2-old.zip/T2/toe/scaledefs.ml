(*

The main purpose of the release of this code is to demonstrate the
author's T2 algorithm for harmonic analysis of jazz chord sequences.

Permission for the use of this code is granted only for research,
educational, and non-commercial purposes.

Redistribution of this code or its parts in source, binary,
and any other form without permission, with or without modification,
is prohibited.  Modifications include, but are not limited to,
translation to other programming languages and reuse of tables,
constant definitions, and API's defined in it.

Andrew Choi is not liable for any losses or damages caused by the use
of this software.

Copyright 2008 Andrew Choi.
http://www.sixthhappiness.ca/T2/index.html

*)

let define name strintvllist =
  Scaletype.define name (Intvllist.of_string strintvllist) in

  define "major" "2.3.4.5.6.7";
  define "harmonic minor" "2.b3.4.5.b6.7";
  define "melodic minor" "2.b3.4.5.6.7";
(*   define "natural minor" "2.b3.4.5.b6.b7"; *)
(*   define "altered" "b2.#2.3.b5.#5.b7"; *)
  define "diminished" "b2.#2.3.b5.5.6.b7";
  define "whole tone" "2.3.b5.#5.b7";
  define "super locrian" "b2.#2.3.b5.#5.b7";
(*   define "blues" "b3.3.4.#4.5.b7"; *)
(*   define "bebop dominant" "2.3.4.5.6.b7.7" *)
